package com.arpb.pickpaygo.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.arpb.pickpaygo.model.CustomerCart;

/**
 * Created by Shivam Pathak on 25/12/2019
 */
@Repository
public interface CustomerCartRepository extends JpaRepository<CustomerCart, Long> {
	Optional<CustomerCart> findByUidpk(Long uidpk);

	List<CustomerCart> findByUidpkIn(List<Long> uidpks);

	/*
	 * @Modifying
	 * 
	 * @Query("update StoreInventory si set si.sold = true where si.uidpk in :qrIds"
	 * ) int setInventorySold(List<Long> qrIds);
	 */

	// Boolean existsByEmail(String email);
}
