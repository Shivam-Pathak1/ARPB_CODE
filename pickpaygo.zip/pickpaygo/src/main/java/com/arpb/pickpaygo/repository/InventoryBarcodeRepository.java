package com.arpb.pickpaygo.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.arpb.pickpaygo.model.InventoryBarcode;

/**
 * Created by Shivam Pathak on 25/12/2019
 */
@Repository
public interface InventoryBarcodeRepository extends JpaRepository<InventoryBarcode, Long> {
    Optional<InventoryBarcode> findByUidpk(Long uidpk);
    List<InventoryBarcode> findByBarcodeId(Long qrId);

    List<InventoryBarcode> findByUidpkIn(List<Long> uidpks);
    
	/*
	 * @Modifying
	 * 
	 * @Query("update InventoryBarcode ib set ib.sold = true where si.barcodeId in :qrIds"
	 * ) int setInventorySold(List<Long> qrIds);
	 * 
	 * @Modifying
	 * 
	 * @Query("update InventoryBarcode ib set ib.addedToCart = true where si.barcodeId in :qrIds"
	 * ) int addInventoryToCart(List<Long> qrIds);
	 */

   // Boolean existsByEmail(String email);
}
