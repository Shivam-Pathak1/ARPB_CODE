package com.arpb.pickpaygo.payload;

public class PaymentResponse {

    private String transactionID;
    private String customerEmail;
    private String response;

    public PaymentResponse(String transactionID, String customerEmail, String response) {
        this.transactionID = transactionID;
        this.customerEmail = customerEmail;
        this.response = response;
    }

    public PaymentResponse(String response) {
        this.response = response;
    }

    public String getTransactionID() {
        return transactionID;
    }

    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }
}
