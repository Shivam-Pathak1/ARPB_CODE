package com.arpb.pickpaygo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.arpb.pickpaygo.payload.ProductRequest;
import com.arpb.pickpaygo.service.WeightService;

@RequestMapping("/api/weight")
@RestController
public class WeightController {

	@Autowired
	WeightService weightService;
	
	@PutMapping("/mapweighingmachine")
	public ResponseEntity<?> mapWeighingMachine(@RequestBody ProductRequest productRequest) {
		return weightService.mapWeighingMachine(productRequest);
	}

	@RequestMapping(value = "/processweight", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> addStoreInventory(@RequestHeader("customerCartId") Long customerCartId) {

		return weightService.processWeight(customerCartId);
	}
}
