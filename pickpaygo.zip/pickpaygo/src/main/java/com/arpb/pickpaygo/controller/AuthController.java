package com.arpb.pickpaygo.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.arpb.pickpaygo.payload.LoginRequest;
import com.arpb.pickpaygo.payload.SignUpRequest;
import com.arpb.pickpaygo.service.PickPayGoService;

/**
 * Created by Shivam Pathak on 25/12/2019
 */
@RestController
@RequestMapping("/api/auth")
public class AuthController {

	@Autowired
	PickPayGoService pickPayGoService;

	@PostMapping("/signin")
	public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginRequest loginRequest) {

		return pickPayGoService.authenticate(loginRequest);

	}

	@PostMapping("/signup")
	public ResponseEntity<?> registerUser(@Valid @RequestBody SignUpRequest signUpRequest) {
		return pickPayGoService.register(signUpRequest);

	}

	@PostMapping("/logout")
	public ResponseEntity<?> logoutUser(@RequestHeader("customerCartId") Long customerCartId) {
		return pickPayGoService.logoutUser(customerCartId);
	}

}
