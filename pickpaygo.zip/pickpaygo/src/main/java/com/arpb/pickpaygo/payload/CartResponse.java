package com.arpb.pickpaygo.payload;

import java.util.ArrayList;
import java.util.List;

public class CartResponse {
	private long cartId;
	private String userEmail;
	private long userId;
	private String name;
	private int numberOfItems=0;
	private float cartWeight = 0.00F;
	private float cartPrice = 0.00F;

	public float getCartPrice() {
		return cartPrice;
	}
	public void setCartPrice(float cartPrice) {
		this.cartPrice =(float) ((float)Math.round(cartPrice * 100.0) / 100.0);
	}
	List<ProductDetail> productdetails = new ArrayList();
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public long getCartId() {
		return cartId;
	}
	public void setCartId(long cartId) {
		this.cartId = cartId;
	}
	public void removeCartProduct(ProductDetail productDetail) {
		productdetails.remove(productDetail);
	}
	public void addCartProduct(ProductDetail productDetail) {
		productdetails.add(productDetail);
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getNumberOfItems() {
		return numberOfItems;
	}
	public void setNumberOfItems(int numberOfItems) {
		this.numberOfItems = numberOfItems;
	}
	public float getCartWeight() {
		return cartWeight;
	}
	public void setCartWeight(float cartWeight) {
		this.cartWeight =(float) ((float)Math.round(cartWeight * 100.0) / 100.0);
	} 

}
