package com.arpb.pickpaygo.model;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.arpb.pickpaygo.model.audit.DateAudit;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

/*
 * CREATE TABLE `customer_cart` (
  `uidpk` int(11) NOT NULL,
  'creationtime'  datetime,
  `checkouttime` datetime,
  'paymentmodeid' int(11),
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`uidpk`)
  
)
**
* Created by Shivam Pathak on 25/12/2019
*/

@Entity
@Table(name = "customer_cart")
public class CustomerCart extends DateAudit {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long uidpk;
	
	
	private String checkOutTime;
	
	private boolean checkedOut;
	
	private float weight;
	
	private float price;
	
	private long weighingMachineId;
	
	
	public long getWeighingMachineId() {
		return weighingMachineId;
	}

	public void setWeighingMachineId(long weighingMachineId) {
		this.weighingMachineId = weighingMachineId;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	//private Long paymentModeId;
	@JsonBackReference
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "paymentModeId", nullable = true)
    private PaymentMode paymentMode;
	
	/*
	 * @NotBlank private Long userid;
	 */
	@JsonBackReference
	@ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "userid", nullable = false)
    private User user;
	
	@JsonManagedReference
	 @OneToMany(fetch = FetchType.EAGER,
		        mappedBy = "customerCart"
		    )
		    private List<CartProduct> cartProducts = new ArrayList<>();
		 
		    //Constructors, getters and setters removed for brevity
		 
		    public void addCartProduct(CartProduct cartProduct) {
		    	cartProducts.add(cartProduct);
		    	cartProduct.setCustomerCart(this);
		    }
		 
		    public void removeCartProduct(CartProduct cartProduct) {
		    	cartProducts.remove(cartProduct);
		    	cartProduct.setCustomerCart(null);
		    }

	public Long getUidpk() {
		return uidpk;
	}

	public void setUidpk(Long uidpk) {
		this.uidpk = uidpk;
	}

	/*
	 * public Date getCreationTime() { return creationTime; }
	 * 
	 * public void setCreationTime(Date creationTime) { this.creationTime =
	 * creationTime; }
	 */

	public boolean isCheckedOut() {
		return checkedOut;
	}

	public void setCheckedOut(boolean checkedOut) {
		this.checkedOut = checkedOut;
	}

	public String getCheckOutTime() {
		return checkOutTime;
	}

	public List<CartProduct> getCartProducts() {
		return cartProducts;
	}

	public void setCartProducts(List<CartProduct> cartProducts) {
		this.cartProducts = cartProducts;
	}

	public void setCheckOutTime(String checkOutTime) {
		this.checkOutTime = checkOutTime;
	}

	public PaymentMode getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(PaymentMode paymentMode) {
		this.paymentMode = paymentMode;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public float getWeight() {
		return weight;
	}

	public void setWeight(float weight) {
		this.weight = weight;
	}

	/* public Long getPaymentModeId() {
		return paymentModeId;
	}

	public void setPaymentModeId(Long paymentModeId) {
		this.paymentModeId = paymentModeId;
	}

	public Long getUserid() {
		return userid;
	}

	public void setUserid(Long userid) {
		this.userid = userid;
	}*/
	
}
