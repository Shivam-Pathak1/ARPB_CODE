package com.arpb.pickpaygo.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.arpb.pickpaygo.model.DepartmentalStore;

/**
 * Created by Shivam Pathak on 25/12/2019
 */
@Repository
public interface DepartmentalStoreRepository extends JpaRepository<DepartmentalStore, Long> {
    Optional<DepartmentalStore> findByUidpk(Long uidpk);

    List<DepartmentalStore> findByUidpkIn(List<Long> uidpks);

    Optional<DepartmentalStore> findByNameAndDescriptionAndLocation(String name, String description, String location);
   // Boolean existsByEmail(String email);
}
