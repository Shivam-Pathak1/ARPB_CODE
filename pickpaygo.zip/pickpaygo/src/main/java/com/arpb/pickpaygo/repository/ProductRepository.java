package com.arpb.pickpaygo.repository;

import com.arpb.pickpaygo.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Created by Shivam Pathak on 25/12/2019
 */
@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
    Optional<Product> findByUidpk(Long uidpk);

    List<Product> findByUidpkIn(List<Long> uidpks);
    
    Optional<Product> findByNameAndDescription(String name, String description);

   // Boolean existsByEmail(String email);
}
