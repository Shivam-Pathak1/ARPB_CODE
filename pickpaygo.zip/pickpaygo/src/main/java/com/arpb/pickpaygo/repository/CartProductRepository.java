package com.arpb.pickpaygo.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.arpb.pickpaygo.model.CartProduct;

/**
 * Created by Shivam Pathak on 25/12/2019
 */
@Repository
public interface CartProductRepository extends JpaRepository<CartProduct, Long> {
    Optional<CartProduct> findByUidpk(Long uidpk);
    Optional<CartProduct> findByStoreInventoryUidpk(Long storeInventoryId);
    CartProduct findByBarcodeId(Long barcodeId);
    List<CartProduct> findByUidpkIn(List<Long> uidpks);
    List<CartProduct> findByCustomerCartUidpk(long customerCartId);
    CartProduct findByBarcodeIdAndCustomerCartUidpk(Long barcodeId,long customerCartId);

   // Boolean existsByEmail(String email);
}
