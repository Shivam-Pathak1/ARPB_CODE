package com.arpb.pickpaygo.payload;

public class PaymentRequest {

	private long customerCartId;
	private String nonce;
	public long getCustomerCartId() {
		return customerCartId;
	}
	public void setCustomerCartId(long customerCartId) {
		this.customerCartId = customerCartId;
	}
	public String getNonce() {
		return nonce;
	}
	public void setNonce(String nonce) {
		this.nonce = nonce;
	}

}
