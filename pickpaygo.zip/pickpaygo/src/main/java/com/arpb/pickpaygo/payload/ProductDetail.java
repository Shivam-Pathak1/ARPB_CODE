package com.arpb.pickpaygo.payload;

public class ProductDetail {
	private String productName;
	private float price;
	private int quantity;
	private long cartProductId;

	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public long getCartProductId() {
		return cartProductId;
	}
	public void setCartProductId(long cartProductId) {
		this.cartProductId = cartProductId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {

		this.price = (float)((float) Math.round(price*100.0)/100.0);
	}
}
