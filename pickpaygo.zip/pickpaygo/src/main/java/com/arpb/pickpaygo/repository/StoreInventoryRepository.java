package com.arpb.pickpaygo.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.arpb.pickpaygo.model.DepartmentalStore;
import com.arpb.pickpaygo.model.Product;
import com.arpb.pickpaygo.model.StoreInventory;

public interface StoreInventoryRepository  extends JpaRepository<StoreInventory, Long> {
	@Query("SELECT s FROM StoreInventory s WHERE s.product.uidpk = ?1 AND s.departmentalStore.uidpk = ?2")
	Optional<StoreInventory> findByProductAndDepartmentalStore(Long productId, Long departmentalStoreId);
}
