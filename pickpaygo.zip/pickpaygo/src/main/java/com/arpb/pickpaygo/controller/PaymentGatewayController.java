package com.arpb.pickpaygo.controller;

import javax.mail.MessagingException;
import javax.validation.constraints.NotBlank;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.arpb.pickpaygo.payload.PaymentRequest;
import com.arpb.pickpaygo.service.PaymentGatewayService;

@RestController
@RequestMapping("/api/payment")
public class PaymentGatewayController {

	@Autowired
	PaymentGatewayService paymentGatewayService;

	@RequestMapping(value = "/checkout", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> processPayment(@NotBlank @RequestBody PaymentRequest paymentRequest)
			throws MessagingException {
		return paymentGatewayService.processPayment(paymentRequest);
	}
}
