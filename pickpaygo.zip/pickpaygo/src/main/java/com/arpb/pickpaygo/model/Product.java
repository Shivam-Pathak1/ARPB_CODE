package com.arpb.pickpaygo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

/*
 * CREATE TABLE `product` (
  `uidpk` int(11) NOT NULL,
  `name` varchar(60) NOT NULL,
  `description` varchar(255) DEFAULT NULL
  PRIMARY KEY (`uidpk`)
 

* Created by Shivam Pathak on 25/12/2019
*/

@Entity
@Table(name = "product")
public class Product {
	private static final long serialVersionUID = 1L;
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long uidpk;

    @NotBlank
    @Size(max = 50)
    private String name;

    @Size(max = 80)
    private String description;

	public Long getUidpk() {
		return uidpk;
	}

	public void setUidpk(Long uidpk) {
		this.uidpk = uidpk;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
    

}
