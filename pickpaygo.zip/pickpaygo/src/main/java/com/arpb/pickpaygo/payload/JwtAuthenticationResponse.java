package com.arpb.pickpaygo.payload;

/**
 * Created by Shivam Pathak on 25/12/2019
 */
public class JwtAuthenticationResponse {
    private String accessToken;
    private String tokenType = "Bearer";
    private long customerCartId;
    private String name;

    public JwtAuthenticationResponse(String accessToken,String name, long customerCartId) {
        this.accessToken = accessToken;
        this.setCustomerCartId(customerCartId);
        this.name=name;
    }
    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getTokenType() {
        return tokenType;
    }

    public void setTokenType(String tokenType) {
        this.tokenType = tokenType;
    }

	public long getCustomerCartId() {
		return customerCartId;
	}

	public void setCustomerCartId(long customerCartId) {
		this.customerCartId = customerCartId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
