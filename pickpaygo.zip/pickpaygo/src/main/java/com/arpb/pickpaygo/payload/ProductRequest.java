package com.arpb.pickpaygo.payload;

public class ProductRequest {

	private long qrId;
	private long customerCartId;
	
	public long getQrId() {
		return qrId;
	}
	public void setQrId(long qrId) {
		this.qrId = qrId;
	}
	public long getCustomerCartId() {
		return customerCartId;
	}
	public void setCustomerCartId(long customerCartId) {
		this.customerCartId = customerCartId;
	}
	
}
