package com.arpb.pickpaygo.repository;

import com.arpb.pickpaygo.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Created by Shivam Pathak on 25/12/2019
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);

    List<User> findByUidpkIn(List<Long> userIds);

    Boolean existsByEmail(String email);
}
