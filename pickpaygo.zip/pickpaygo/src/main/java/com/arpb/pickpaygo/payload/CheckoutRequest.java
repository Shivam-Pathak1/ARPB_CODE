package com.arpb.pickpaygo.payload;

public class CheckoutRequest {
	private String nonce;
	private long customerCartId;
	
	
	public String getNonce() {
		return nonce;
	}
	public void setNonce(String nonce) {
		this.nonce = nonce;
	}
	public long getCustomerCartId() {
		return customerCartId;
	}
	public void setCustomerCartId(long customerCartId) {
		this.customerCartId = customerCartId;
	}
}
