package com.arpb.pickpaygo.controller;

import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.arpb.pickpaygo.payload.ProductRequest;
import com.arpb.pickpaygo.service.PickPayGoService;

@RestController
@RequestMapping("/api/product")
public class ProductController {


	@Autowired
	PickPayGoService pickPayGoService;
	@RequestMapping(value = "/addproduct", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> addProductInCart(@NotBlank @RequestBody ProductRequest productRequest) {

		return pickPayGoService.addProdToCart(productRequest) ;
	}

	@GetMapping("/getCart")
	public ResponseEntity<?> getCart(@RequestHeader("customerCartId") Long customerCartId) {
		return pickPayGoService.getCart(customerCartId);
	}

	@RequestMapping(value = "/deleteproduct", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> deleteProductInCart(@NotBlank @RequestBody ProductRequest productRequest) {
		return pickPayGoService.removeFromCart(productRequest);
	}
	/*
	 * @RequestMapping(value = "/checkout", method = RequestMethod.POST, produces =
	 * "application/json") public ResponseEntity<?>
	 * checkoutCart(@NotBlank @RequestBody ProductRequest productRequest) throws
	 * MessagingException { return pickPayGoService.checkoutCart(productRequest); }
	 */
}
