package com.arpb.pickpaygo.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.json.JSONArray;
import org.springframework.stereotype.Component;

import com.arpb.pickpaygo.model.CartProduct;
import com.arpb.pickpaygo.model.CustomerCart;
import com.arpb.pickpaygo.payload.CartResponse;
import com.arpb.pickpaygo.payload.ProductDetail;
import com.arpb.pickpaygo.repository.CartProductRepository;
import com.arpb.pickpaygo.repository.CustomerCartRepository;
import com.google.gson.Gson;

@Component 
public class ServiceUtil {

	public String generateCartResponse(long customerCartId, CartProductRepository cartProductRepository, CustomerCartRepository customerCartRepository ) {
		List<CartProduct> cartProducts = cartProductRepository
				.findByCustomerCartUidpk(customerCartId);

		Optional<CustomerCart> customerCart = customerCartRepository.findByUidpk(customerCartId);
		CustomerCart customerCart2 = customerCart.get();
		CartResponse cartResponse = new CartResponse();
		cartResponse.setCartId(customerCart2.getUidpk());
		cartResponse.setUserEmail(customerCart2.getUser().getEmail());
		cartResponse.setName(customerCart2.getUser().getName());
		cartResponse.setUserId(customerCart2.getUser().getUidpk());
		cartResponse.setCartWeight(customerCart2.getWeight());
		cartResponse.setCartPrice(customerCart2.getPrice());
		// List<CartProduct> cartProducts = customerCart2.getCartProducts();
		int quantityPurchased=0;

		for (CartProduct cartProduct2 : cartProducts) {
			quantityPurchased+=cartProduct2.getQuantity();
			ProductDetail productDetail = new ProductDetail();
			productDetail.setCartProductId(cartProduct2.getUidpk());
			productDetail.setPrice(cartProduct2.getStoreInventory().getPrice());
			productDetail.setQuantity(cartProduct2.getQuantity());
			productDetail.setProductName(cartProduct2.getStoreInventory().getProduct().getName());
			cartResponse.addCartProduct(productDetail);
		}
		cartResponse.setNumberOfItems(quantityPurchased);
		return generateJsonResponse(cartResponse);
	}

	public String generateJsonResponse(Object object) {
		Gson gson = new Gson();
		return gson.toJson(object);
	}

	public String dateFormat() {
		java.util.Date dt = new java.util.Date();

		java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		String currentTime = sdf.format(dt);
		return currentTime;
	}
	public void sendEmail(String userDetails) throws MessagingException {

		org.json.JSONObject obj = new org.json.JSONObject(userDetails);
		List<String> stringList = new ArrayList<String>();
		List<Float> stringPrice = new ArrayList<Float>();
		List<Integer> stringQuantity = new ArrayList<Integer>();

		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");

		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication("pickpaygoservice@gmail.com", "applicationarp");
			}
		});
		Message msg = new MimeMessage(session);
		msg.setFrom(new InternetAddress("tutorialspoint@gmail.com", false));

		msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(obj.get("userEmail").toString().trim()));
		msg.setSubject("Pick-Pay Payment Details");
		msg.setSentDate(new Date());

		JSONArray arr = obj.getJSONArray("productdetails");

		Multipart multipart = new MimeMultipart();
		MimeBodyPart messageBodyPart = new MimeBodyPart();
		for (int i = 0; i < arr.length(); i++) {
			String id = arr.getJSONObject(i).getString("productName");
			stringList.add(id);
		}

		for (int i = 0; i < arr.length(); i++) {
			Float id = arr.getJSONObject(i).getFloat("price");
			stringPrice.add(id);
		}
		for (int i = 0; i < arr.length(); i++) {
			Integer id = arr.getJSONObject(i).getInt("quantity");
			stringQuantity.add(id);
		}
		StringBuilder buf = new StringBuilder();
		buf.append("<html>" + "<body> Dear <b style='color:red;'>" + obj.get("name") + "</b>,"
				+ "\n Thank you for shopping with us Please find below your cart information, <p></p><table>" + "<tr>"
				+ "<th>Product</th>"+ "<th>|</th>" + "<th>Price</th>"+ "<th>|</th>" + "<th>Quantity</th>" + "</tr>");
		for (int i = 0; i < stringList.size(); i++) {
			buf.append("<tr><td>").append(stringList.get(i)).append("</td><td>").append("|").append("</td><td>").append(stringPrice.get(i)).append("</td><td>").append("|").append("</td><td>").append(stringQuantity.get(i))
			.append("</td></tr>");
		}
		buf.append("</table>" + "\n <tr><td><span style=\"font-weight:bold\">Total Price</span> </td><td> "
				+ obj.get("cartPrice") + "</td></tr>  </body>" + "</html>");
		String html = buf.toString();
		messageBodyPart.setContent(html, "text/html");
		multipart.addBodyPart(messageBodyPart);

		messageBodyPart = new MimeBodyPart();
		DataSource fds = new FileDataSource("D:\\android2\\qrcode\\app\\src\\main\\res\\drawable\\ppg.png");

		messageBodyPart.setDataHandler(new DataHandler(fds));
		messageBodyPart.setHeader("Content-ID", "<image>");

		// add image to the multipart
		multipart.addBodyPart(messageBodyPart);

		msg.setContent(multipart);
		Transport.send(msg);
	}

}
