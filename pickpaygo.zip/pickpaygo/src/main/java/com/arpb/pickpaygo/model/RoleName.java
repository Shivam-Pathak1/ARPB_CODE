package com.arpb.pickpaygo.model;

/**
 * Created by Shivam Pathak on 25/12/2019
 */
public enum  RoleName {
    ROLE_USER,
    ROLE_ADMIN
}
