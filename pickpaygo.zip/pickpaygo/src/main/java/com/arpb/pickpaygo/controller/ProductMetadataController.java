package com.arpb.pickpaygo.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.arpb.pickpaygo.payload.Inventory;
import com.arpb.pickpaygo.service.ProductMetadataService;

@RequestMapping("/api/metadata")
@RestController
public class ProductMetadataController {

    @Autowired
    ProductMetadataService shopEasyService;


    @RequestMapping(value = "/insertproduct", method = RequestMethod.POST, produces = "application/json")
    public ResponseEntity<?> addProduct(@Valid @RequestBody Inventory addProduct) {

        return shopEasyService.insertProduct(addProduct);
    }

    @RequestMapping(value = "/insertinventory", method = RequestMethod.POST, produces = "application/json")
    public ResponseEntity<?> addStoreInventory(@Valid @RequestBody Inventory addProduct) {

        return shopEasyService.insertInventory(addProduct);
    }

    @RequestMapping(value = "/insertstore", method = RequestMethod.POST, produces = "application/json")
    public ResponseEntity<?> addDepartment(@Valid @RequestBody Inventory addDepartment) {

        return shopEasyService.insertStore(addDepartment);
    }

}
