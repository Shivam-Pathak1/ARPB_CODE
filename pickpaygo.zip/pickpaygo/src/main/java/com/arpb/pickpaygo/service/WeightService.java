package com.arpb.pickpaygo.service;

import java.util.HashMap;
import java.util.Optional;
import org.eclipse.paho.client.mqttv3.IMqttClient;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.arpb.pickpaygo.PickPayGoApplication;
import com.arpb.pickpaygo.exception.AppException;
import com.arpb.pickpaygo.model.CustomerCart;
import com.arpb.pickpaygo.model.User;
import com.arpb.pickpaygo.model.WeighingMachine;
import com.arpb.pickpaygo.payload.ApiResponse;
import com.arpb.pickpaygo.payload.ProductRequest;
import com.arpb.pickpaygo.repository.CartProductRepository;
import com.arpb.pickpaygo.repository.CustomerCartRepository;
import com.arpb.pickpaygo.repository.WeighingMachineRepository;
import com.arpb.pickpaygo.util.ServiceUtil;
import com.braintreegateway.BraintreeGateway;
import com.braintreegateway.ClientTokenRequest;
import com.braintreegateway.Customer;
import com.braintreegateway.CustomerRequest;
import com.braintreegateway.Result;
import com.braintreegateway.exceptions.NotFoundException;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

@Service
public class WeightService {

	private BraintreeGateway gateway = PickPayGoApplication.gateway;

	@Autowired
	WeighingMachineRepository weighingMachineRepository;
	@Autowired
	CustomerCartRepository customerCartRepository;
	@Autowired
	CartProductRepository cartProductRepository;
	@Autowired
	ServiceUtil serviceUtil;
	public ResponseEntity mapWeighingMachine(ProductRequest productRequest)
	{
		Optional<CustomerCart> customerCart=customerCartRepository.findByUidpk(productRequest.getCustomerCartId());
		if(customerCart.isPresent())
		{
			Optional<WeighingMachine> weighOptional = weighingMachineRepository.findByMachineBarcode(productRequest.getQrId());
			if(weighOptional.isPresent())
			{
				CustomerCart cart = customerCart.get();
				cart.setWeighingMachineId(weighOptional.get().getUidpk());
				customerCartRepository.save(cart);
			}
			else
				throw new AppException("Weighing Machine Scan could not be validated");
		}
		else
			throw new AppException("Could not fetch cart.");
		return new ResponseEntity(new ApiResponse(true, serviceUtil.generateCartResponse(productRequest.getCustomerCartId(),cartProductRepository,customerCartRepository)), HttpStatus.OK);
	}
	public ResponseEntity processWeight(long customerCartId)
	{
		Optional<CustomerCart> optional  = customerCartRepository.findByUidpk(customerCartId);
		if(!optional.isPresent())
		{
			throw new AppException("Cart could not be found for the user");
		}
		CustomerCart cart=optional.get();
		User user = cart.getUser();
		JsonArray jsonArray = new JsonArray();
		IMqttClient mqttClient;
		try {
			mqttClient = new MqttClient("tcp://" + "192.168.0.73" + ":" + "1883", "arduinoClient2");
			mqttClient.connect(new MqttConnectOptions());

			mqttClient.subscribeWithResponse("ARPAHAHA", (tpic, msg) -> {
				String str = new String(msg.getPayload());
				jsonArray.add(str);
				System.out.println(msg.getId() + " -> " + new String(msg.getPayload()));
			});
			JsonObject obj = jsonArray.getAsJsonObject();
			long weighingMachineId=obj.get("id").getAsLong();
			float weight=obj.get("weight").getAsFloat();
			if(weighingMachineId == cart.getWeighingMachineId())
			{
				if((weight - cart.getWeight() < 30.0) ||  (cart.getWeight() - weight > 30.0))
				{
					return getClientToken(user);
				}
				else
				{
					throw new AppException("Weights do not match");

				}
			}
			throw new AppException("Error connecting weighing machine to the server");
		} catch (MqttException e) {
			// TODO Auto-generated catch block
			throw new AppException("Error processing weights");
		}
	}
	private ResponseEntity getClientToken(User user) {
		ClientTokenRequest clientTokenRequest;
		Customer customer;
		try {
			customer = gateway.customer().find(String.valueOf(user.getUidpk()));
		} catch (NotFoundException notFoundException) {
			CustomerRequest request = new CustomerRequest()
					.firstName(user.getName())
					.email(user.getEmail())
					.id(String.valueOf(user.getUidpk()));
			Result<Customer> customerresult = gateway.customer().create(request);
			customer = customerresult.getTarget();
		}
		clientTokenRequest = new ClientTokenRequest()
				.customerId(customer.getId());
		String clientToken = gateway.clientToken().generate(clientTokenRequest);
		HashMap<String, String> map = new HashMap<>();
		System.out.println(clientToken);
		map.put("clientToken", clientToken);
		return new ResponseEntity(map, HttpStatus.OK);
	}
}
