package com.arpb.pickpaygo.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.arpb.pickpaygo.model.PaymentMode;

/**
 * Created by Shivam Pathak on 25/12/2019
 */
@Repository
public interface PaymentModeRepository extends JpaRepository<PaymentMode, Long> {
    Optional<PaymentMode> findByUidpk(Long uidpk);
    
    List<PaymentMode> findByUidpkIn(List<Long> uidpks);
    

   // Boolean existsByEmail(String email);
}
