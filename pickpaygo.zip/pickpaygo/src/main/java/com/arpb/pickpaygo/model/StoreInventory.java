package com.arpb.pickpaygo.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/*
 * CREATE TABLE `store_inventory` (
  `uidpk` int(11) NOT NULL,
  'storeid'  int(11) NOT NULL,
  `productid` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  'qrid' bigint(20) NOT NULL,
  `price` float NOT NULL,
  'sold' boolean
  PRIMARY KEY (`uidpk`)

)
 **
 * Created by Shivam Pathak on 25/12/2019
 */

@Entity
@Table(name = "store_inventory")
public class StoreInventory {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long uidpk;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "storeId", nullable = false)
	private DepartmentalStore departmentalStore;
	/*
	 * @NotNull private Long storeId;
	 */

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "productId", nullable = false)
	private Product product;
	/*
	 * @NotNull private Long productId;
	 */

	@Size(max = 100)
	private String description;

	/*
	 * @NotNull private Long qrId;
	 */

	@NotNull
	private Float price;

	@NotNull
	private Float weight;

	@NotNull
	private Long stockSize;

	public Float getWeight() {
		return weight;
	}
	public void setWeight(Float weight) {
		this.weight = weight;
	}
	public Long getStockSize() {
		return stockSize;
	}
	public void setStockSize(Long stockSize) {
		this.stockSize = stockSize;
	}
	public void setPrice(Float price) {
		this.price = price;
	}
	/*
	 * private boolean sold;
	 * 
	 * private boolean addedToCart;



	    public boolean isAddedToCart() {
			return addedToCart;
		}
		public void setAddedToCart(boolean addedToCart) {
			this.addedToCart = addedToCart;
		}
		public boolean isSold() {
			return sold;
		}
		public void setSold(boolean sold) {
			this.sold = sold;
		}
		public Long getQrId() {
			return qrId;
		}
		public void setQrId(Long qrId) {
			this.qrId = qrId;
		}
	 */
	public StoreInventory(){

	}
	public StoreInventory(Product product,DepartmentalStore departmentalStore,float weight, long stockSize,float price, String description){
		// this.productId = productId;
		this.product=product;
		this.price = price;
		this.weight = weight;
		this.stockSize=stockSize;
		//this.storeId = storeId;
		this.departmentalStore = departmentalStore;
		this.description = description;
	}
	public Long getUidpk() {
		return uidpk;
	}
	public void setUidpk(Long uidpk) {
		this.uidpk = uidpk;
	}

	/*
	 * public Long getStoreId() { return storeId; } public void setStoreId(Long
	 * storeId) { this.storeId = storeId; }

		public Long getProductId() {
			return productId;
		}
		public void setProductId(Long productId) {
			this.productId = productId;
		}
	 */

	public String getDescription() {
		return description;
	}
	public DepartmentalStore getDepartmentalStore() {
		return departmentalStore;
	}
	public void setDepartmentalStore(DepartmentalStore departmentalStore) {
		this.departmentalStore = departmentalStore;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public void setDescription(String description) {
		this.description = description;
	}

	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}




}
