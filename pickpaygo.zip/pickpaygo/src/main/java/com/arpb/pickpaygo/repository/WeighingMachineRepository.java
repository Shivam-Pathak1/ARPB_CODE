package com.arpb.pickpaygo.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.arpb.pickpaygo.model.WeighingMachine;

/**
 * Created by Shivam Pathak on 25/12/2019
 */
@Repository
public interface WeighingMachineRepository extends JpaRepository<WeighingMachine, Long> {
    Optional<WeighingMachine> findByUidpk(Long uidpk);

    List<WeighingMachine> findByUidpkIn(List<Long> uidpks);
    
    Optional<WeighingMachine> findByMachineBarcode(Long machineBarcode);

}
