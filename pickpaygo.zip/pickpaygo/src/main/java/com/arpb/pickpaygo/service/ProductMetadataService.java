package com.arpb.pickpaygo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.arpb.pickpaygo.model.DepartmentalStore;
import com.arpb.pickpaygo.model.InventoryBarcode;
import com.arpb.pickpaygo.model.Product;
import com.arpb.pickpaygo.model.StoreInventory;
import com.arpb.pickpaygo.payload.ApiResponse;
import com.arpb.pickpaygo.payload.Inventory;
import com.arpb.pickpaygo.repository.DepartmentalStoreRepository;
import com.arpb.pickpaygo.repository.InventoryBarcodeRepository;
import com.arpb.pickpaygo.repository.ProductRepository;
import com.arpb.pickpaygo.repository.StoreInventoryRepository;

@Service
public class ProductMetadataService {

	@Autowired
	private StoreInventoryRepository storeInventoryRepository;

	@Autowired
	private InventoryBarcodeRepository inventoryBarcodeRepository;

	@Autowired
	private ProductRepository productRepository;


	@Autowired
	private DepartmentalStoreRepository departmentalStoreRepository;

	public ResponseEntity insertProduct(Inventory addProduct) {

		Product product = new Product();
		product.setName(addProduct.getProductName());
		product.setDescription(addProduct.getProductDescription());
		Product productDetails = productRepository.save(product);
		return ResponseEntity.ok(new ApiResponse(true, "Item added successfully"));

	}

	public ResponseEntity insertInventory(Inventory addProduct) {

		Optional<Product> productOptional = productRepository.findByNameAndDescription(addProduct.getProductName(), addProduct.getProductDescription());
		Product product = new Product();
		if(productOptional.isPresent())
		{
			product= productOptional.get();
		}
		else
		{
			product.setName(addProduct.getProductName());
			product.setDescription(addProduct.getProductDescription());
			product = productRepository.save(product);
		}

		Optional<DepartmentalStore> departmentalStoreOptional = departmentalStoreRepository.findByNameAndDescriptionAndLocation(addProduct.getStoreName(), addProduct.getStoreDescription(),addProduct.getStoreLocation());
		DepartmentalStore departmentalStore = new DepartmentalStore();
		if(departmentalStoreOptional.isPresent())
		{
			departmentalStore= departmentalStoreOptional.get();
		}
		else
		{
			departmentalStore.setName(addProduct.getStoreName());
			departmentalStore.setDescription(addProduct.getStoreDescription());
			departmentalStore.setLocation(addProduct.getStoreLocation());
			departmentalStore = departmentalStoreRepository.save(departmentalStore);
		}

		StoreInventory storeInventory = new StoreInventory();
		Optional<StoreInventory> storeInventoryOpt = storeInventoryRepository.findByProductAndDepartmentalStore(product.getUidpk(), departmentalStore.getUidpk());
		if(storeInventoryOpt.isPresent())
		{
			storeInventory=storeInventoryOpt.get();
			long quantity = storeInventory.getStockSize()+1;
			storeInventory.setStockSize(quantity);
		}
		else
			storeInventory = new StoreInventory(product, departmentalStore, addProduct.getWeight(), addProduct.getStockSize(), addProduct.getPrice(), addProduct.getInventoryDescription());
		storeInventory=storeInventoryRepository.save(storeInventory);

		InventoryBarcode inventorybarcode = new InventoryBarcode(storeInventory,addProduct.getBarcodeId());
		inventorybarcode = inventoryBarcodeRepository.save(inventorybarcode);
		return ResponseEntity.ok(new ApiResponse(true, "Item added successfully"));

	}


	public ResponseEntity insertStore(Inventory addDepartment) {
		DepartmentalStore departmentalStore = new DepartmentalStore();
		departmentalStore.setName(addDepartment.getStoreName());
		departmentalStore.setLocation(addDepartment.getStoreLocation());
		departmentalStore.setDescription(addDepartment.getStoreDescription());

		DepartmentalStore productDetails = departmentalStoreRepository.save(departmentalStore);
		return ResponseEntity.ok(new ApiResponse(true, "Item added successfully"));
	}

}
