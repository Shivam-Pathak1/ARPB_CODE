package com.arpb.pickpaygo.repository;

import com.arpb.pickpaygo.model.Role;
import com.arpb.pickpaygo.model.RoleName;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Created by Shivam Pathak on 25/12/2019
 */
@Repository
public interface RoleRepository extends JpaRepository<Role, Long> {
    Optional<Role> findByName(RoleName roleName);
}
