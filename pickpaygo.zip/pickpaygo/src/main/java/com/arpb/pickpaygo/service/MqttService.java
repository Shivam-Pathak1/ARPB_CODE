package com.arpb.pickpaygo.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.eclipse.paho.client.mqttv3.IMqttClient;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.arpb.pickpaygo.exception.AppException;
import com.arpb.pickpaygo.model.CartProduct;
import com.arpb.pickpaygo.model.CustomerCart;
import com.arpb.pickpaygo.model.InventoryBarcode;
import com.arpb.pickpaygo.model.Role;
import com.arpb.pickpaygo.model.RoleName;
import com.arpb.pickpaygo.model.StoreInventory;
import com.arpb.pickpaygo.model.User;
import com.arpb.pickpaygo.payload.ApiResponse;
import com.arpb.pickpaygo.payload.CartResponse;
import com.arpb.pickpaygo.payload.JwtAuthenticationResponse;
import com.arpb.pickpaygo.payload.LoginRequest;
import com.arpb.pickpaygo.payload.ProductDetail;
import com.arpb.pickpaygo.payload.ProductRequest;
import com.arpb.pickpaygo.payload.SignUpRequest;
import com.arpb.pickpaygo.repository.CartProductRepository;
import com.arpb.pickpaygo.repository.CustomerCartRepository;
import com.arpb.pickpaygo.repository.InventoryBarcodeRepository;
import com.arpb.pickpaygo.repository.RoleRepository;
import com.arpb.pickpaygo.repository.UserRepository;
import com.arpb.pickpaygo.security.JwtTokenProvider;
import com.google.gson.Gson;

@Service
public class MqttService {

	
	public ResponseEntity mqttTrial() throws MqttException {
		
		
		IMqttClient mqttClient = new MqttClient("tcp://" + "192.168.0.73" + ":" + "1883", "arduinoClient2");

		mqttClient.connect(new MqttConnectOptions());

		mqttClient.subscribeWithResponse("ARPAHAHA", (tpic, msg) -> {
			System.out.println(msg.getId() + " -> " + new String(msg.getPayload()));
		});
		return new ResponseEntity(HttpStatus.OK);
	}
	
	
}
