package com.arpb.pickpaygo.service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import com.arpb.pickpaygo.exception.AppException;
import com.arpb.pickpaygo.model.CartProduct;
import com.arpb.pickpaygo.model.CustomerCart;
import com.arpb.pickpaygo.model.InventoryBarcode;
import com.arpb.pickpaygo.model.Role;
import com.arpb.pickpaygo.model.RoleName;
import com.arpb.pickpaygo.model.StoreInventory;
import com.arpb.pickpaygo.model.User;
import com.arpb.pickpaygo.payload.ApiResponse;
import com.arpb.pickpaygo.payload.JwtAuthenticationResponse;
import com.arpb.pickpaygo.payload.LoginRequest;
import com.arpb.pickpaygo.payload.ProductRequest;
import com.arpb.pickpaygo.payload.SignUpRequest;
import com.arpb.pickpaygo.repository.CartProductRepository;
import com.arpb.pickpaygo.repository.CustomerCartRepository;
import com.arpb.pickpaygo.repository.InventoryBarcodeRepository;
import com.arpb.pickpaygo.repository.RoleRepository;
import com.arpb.pickpaygo.repository.StoreInventoryRepository;
import com.arpb.pickpaygo.repository.UserRepository;
import com.arpb.pickpaygo.security.JwtTokenProvider;
import com.arpb.pickpaygo.util.ServiceUtil;

@Service
public class PickPayGoService {

	/*
	 * @Autowired private CartRepo cartRepo;
	 */

	/*
	 * @Autowired private ProductService productService;
	 */
	@Autowired
	private InventoryBarcodeRepository inventoryBarcodeRepository;

	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	private CartProductRepository cartProductRepository;

	@Autowired
	UserRepository userRepository;

	@Autowired
	CustomerCartRepository customerCartRepository;

	@Autowired
	RoleRepository roleRepository;

	@Autowired
	PasswordEncoder passwordEncoder;

	@Autowired
	JwtTokenProvider tokenProvider;

	@Autowired
	StoreInventoryRepository storeInventoryRepository;

	@Autowired
	ServiceUtil serviceUtil;

	public ResponseEntity register(SignUpRequest signUpRequest) {
		if (userRepository.existsByEmail(signUpRequest.getEmail())) {
			return new ResponseEntity(new ApiResponse(false, "Email Address already in use!"), HttpStatus.OK);
		}

		// Creating user's account
		User user = new User(signUpRequest.getName(), signUpRequest.getEmail(), signUpRequest.getPassword());

		user.setPassword(passwordEncoder.encode(user.getPassword()));
		Role userRole = new Role();
		if(signUpRequest.isRole())
		{
			userRole=roleRepository.findByName(RoleName.ROLE_ADMIN)
					.orElseThrow(() -> new AppException("User Role not set."));
		}
		else
		{
			userRole = roleRepository.findByName(RoleName.ROLE_USER)
					.orElseThrow(() -> new AppException("User Role not set."));
		}
		user.setRoles(Collections.singleton(userRole));
		User result = userRepository.save(user);
		return ResponseEntity.ok(new ApiResponse(true, "User registered successfully"));
	}

	public ResponseEntity authenticate(LoginRequest loginRequest) {
		Authentication authentication = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(loginRequest.getEmail(), loginRequest.getPassword()));

		SecurityContextHolder.getContext().setAuthentication(authentication);

		String jwt = tokenProvider.generateToken(authentication);
		Optional<User> userOptional = userRepository.findByEmail(loginRequest.getEmail());
		if (!userOptional.isPresent()) {
			return new ResponseEntity(new ApiResponse(false, "Email not found!"), HttpStatus.OK);
		}
		User user = userOptional.get();
		user.setLastLoginTime(serviceUtil.dateFormat());
		CustomerCart customerCart = new CustomerCart();
		customerCart.setUser(user);
		customerCart = customerCartRepository.save(customerCart);
		JwtAuthenticationResponse authenticationResponse = new JwtAuthenticationResponse(jwt, user.getName(),
				customerCart.getUidpk());
		return ResponseEntity.ok(new ApiResponse(true, serviceUtil.generateJsonResponse(authenticationResponse)));

	}

	public ResponseEntity logoutUser(Long customerCartId) {
		Optional<CustomerCart> customerCartOptional = customerCartRepository.findByUidpk(customerCartId);
		if (!customerCartOptional.isPresent()) {
			return new ResponseEntity(new ApiResponse(false, "Cart not found!"), HttpStatus.OK);
		}
		CustomerCart customerCart = customerCartOptional.get();

		if(!customerCart.isCheckedOut())
		{
			customerCart.setPrice(0);
			customerCart.setWeight(0);
			List<CartProduct> cartProducts = cartProductRepository.findByCustomerCartUidpk(customerCartId);
			for (CartProduct cartProduct : cartProducts) {
				cartProduct.setQuantity(0);
				cartProductRepository.save(cartProduct);
			}
			customerCartRepository.save(customerCart);
		}

		User user = customerCart.getUser();
		user.setLastLogoutTime(serviceUtil.dateFormat());
		user = userRepository.save(user);

		return ResponseEntity.ok(new ApiResponse(true, "User logged out successfully"));
	}

	private ApiResponse validate(ProductRequest productRequest)
	{
		Optional<CustomerCart> customerCartOptional = customerCartRepository
				.findByUidpk(productRequest.getCustomerCartId());
		if (!customerCartOptional.isPresent()) {
			return new ApiResponse(false, "Cart could not be found for the user");
		}
		CustomerCart customerCart=customerCartOptional.get();
		if(customerCart.isCheckedOut())
		{
			return new ApiResponse(false, "Cart is already checked out");
		}
		List<InventoryBarcode> inventoryBarcodes = inventoryBarcodeRepository.findByBarcodeId(productRequest.getQrId());

		//Optional<StoreInventory> storeInventory = inventoryBarcodeRepository.findByBarcodeId(productRequest.getQrId());
		if (inventoryBarcodes.isEmpty()) {
			return new ApiResponse(false, "Product not found in database");
			/*
			 * return new ResponseEntity(new ApiResponse(false, "Product not found"),
			 * HttpStatus.OK);
			 */
		}
		return new ApiResponse(true,"Request Validated");
	}
	public ResponseEntity getCart(long customerCartId)
	{
		Optional<CustomerCart> cart = customerCartRepository.findByUidpk(customerCartId);
		if(!cart.isPresent())
		{
			throw new AppException("Cart could not be found for the user");
		}
		return new ResponseEntity(new ApiResponse(true, serviceUtil.generateCartResponse(customerCartId, cartProductRepository, customerCartRepository)), HttpStatus.OK);
	}
	public ResponseEntity addProdToCart(ProductRequest productRequest) {
		ApiResponse apiResponse=validate(productRequest);
		if(!apiResponse.getSuccess())
		{
			return new ResponseEntity(apiResponse,HttpStatus.OK);
		}
		CustomerCart customerCart;
		StoreInventory storeInventory;
		CartProduct cartProduct = cartProductRepository.findByBarcodeIdAndCustomerCartUidpk(productRequest.getQrId(),productRequest.getCustomerCartId());
		if(cartProduct==null)
		{
			cartProduct = new CartProduct();
			customerCart = customerCartRepository.findByUidpk(productRequest.getCustomerCartId()).get();
			List<InventoryBarcode> inventoryBarcodes = inventoryBarcodeRepository.findByBarcodeId(productRequest.getQrId());
			storeInventory=inventoryBarcodes.get(0).getStoreInventory();
			cartProduct.setStoreInventory(storeInventory);
			cartProduct.setBarcodeId(productRequest.getQrId());	
		}
		else
		{
			storeInventory=cartProduct.getStoreInventory();
			if(cartProduct.getQuantity()>=storeInventory.getStockSize())
			{
				throw new AppException("This product is limited in stock.");
			}
			customerCart=cartProduct.getCustomerCart();

		}
		int quantity = cartProduct.getQuantity()+1;
		float productWeight = storeInventory.getWeight();
		float cartWeight = customerCart.getWeight() + productWeight;
		float productPrice = storeInventory.getPrice();
		float cartPrice = customerCart.getPrice() + productPrice;
		customerCart.setPrice(cartPrice);
		customerCart.setWeight(cartWeight);
		cartProduct.setCustomerCart(customerCart);
		cartProduct.setQuantity(quantity);


		cartProduct = cartProductRepository.save(cartProduct);
		return new ResponseEntity(new ApiResponse(true, serviceUtil.generateCartResponse(productRequest.getCustomerCartId(),cartProductRepository,customerCartRepository)), HttpStatus.OK);
	}

	public ResponseEntity removeFromCart(ProductRequest productRequest) {
		ApiResponse apiResponse=validate(productRequest);
		CartProduct cartProduct = cartProductRepository.findByBarcodeIdAndCustomerCartUidpk(productRequest.getQrId(),productRequest.getCustomerCartId());
		if(cartProduct==null)
		{
			throw new AppException("Product not found in cart");
		}
		CustomerCart customerCart= cartProduct.getCustomerCart();
		StoreInventory storeInventory= cartProduct.getStoreInventory();
		float productWeight = storeInventory.getWeight();
		float cartWeight = customerCart.getWeight() - productWeight;
		float productPrice = storeInventory.getPrice();
		float cartPrice = customerCart.getPrice() - productPrice;
		customerCart.setWeight(cartWeight);
		customerCart.setPrice(cartPrice);
		customerCartRepository.save(customerCart);
		if(cartProduct.getQuantity()==1)
		{
			cartProductRepository.delete(cartProduct);
		}
		else
		{
			int quantity = cartProduct.getQuantity()-1;
			cartProduct.setQuantity(quantity);
			cartProductRepository.save(cartProduct);
		}
		return new ResponseEntity(new ApiResponse(true, serviceUtil.generateCartResponse(productRequest.getCustomerCartId(),cartProductRepository,customerCartRepository)), HttpStatus.OK);
	}

	/*
	 * public ResponseEntity checkoutCart(long productRequest) throws
	 * MessagingException { long customerCartId =
	 * productRequest.getCustomerCartId(); Optional<CustomerCart>
	 * customerCartOptional = customerCartRepository.findByUidpk(customerCartId);
	 * if(!customerCartOptional.isPresent()) { throw new
	 * AppException("Cart could not be found for the user"); } CustomerCart
	 * customerCart = customerCartOptional.get(); List<CartProduct> cartProducts
	 * =customerCart.getCartProducts(); for(CartProduct product: cartProducts) {
	 * StoreInventory inventory = product.getStoreInventory();
	 * inventory.setStockSize(inventory.getStockSize()-product.getQuantity());
	 * storeInventoryRepository.save(inventory); }
	 * customerCart.setCheckOutTime(serviceUtil.dateFormat());
	 * customerCart.setCheckedOut(true); customerCart =
	 * customerCartRepository.save(customerCart); logoutUser(customerCartId); //
	 * String userDetails = generateSoldProductResponse(productRequest); String
	 * userDetails =
	 * serviceUtil.generateCartResponse(productRequest.getCustomerCartId(),
	 * cartProductRepository,customerCartRepository);
	 * serviceUtil.sendEmail(userDetails); return ResponseEntity.ok(new
	 * ApiResponse(true, "User logged out successfully")); }
	 */
}
