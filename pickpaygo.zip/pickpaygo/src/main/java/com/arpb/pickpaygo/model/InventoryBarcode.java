package com.arpb.pickpaygo.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

/**
 * Created by Shivam Pathak on 25/12/2019
 */

@Entity
@Table(name = "inventory_barcode")
public class InventoryBarcode {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long uidpk;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "inventoryId", nullable = false)
	private StoreInventory storeInventory;
	@NotNull 
	private Long  barcodeId;
	
	InventoryBarcode() {
		// TODO Auto-generated constructor stub
	}
	public InventoryBarcode(StoreInventory storeInventory, long barcodeId) {
		this.barcodeId=barcodeId;
		this.storeInventory=storeInventory;
		// TODO Auto-generated constructor stub
	}
	
	public Long getUidpk() {
		return uidpk;
	}
	public void setUidpk(Long uidpk) {
		this.uidpk = uidpk;
	}
	public StoreInventory getStoreInventory() {
		return storeInventory;
	}
	public void setStoreInventory(StoreInventory storeInventory) {
		this.storeInventory = storeInventory;
	}
	public Long getBarcodeId() {
		return barcodeId;
	}
	public void setBarcodeId(Long barcodeId) {
		this.barcodeId = barcodeId;
	}

}
