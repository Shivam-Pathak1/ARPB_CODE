package com.arpb.pickpaygo.payload;

public class Inventory {

	private String inventoryDescription;
	private String productName;
    private String productDescription;
    private String storeName;
    private String storeDescription;
    private String storeLocation;
    private float price;
    private float weight;
    private long barcodeId;
    private long stockSize;
    
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public String getStoreName() {
		return storeName;
	}
	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}
	public String getStoreDescription() {
		return storeDescription;
	}
	public void setStoreDescription(String storeDescription) {
		this.storeDescription = storeDescription;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public float getWeight() {
		return weight;
	}
	public void setWeight(float weight) {
		this.weight = weight;
	}
	public long getBarcodeId() {
		return barcodeId;
	}
	public void setBarcodeId(long barcodeId) {
		this.barcodeId = barcodeId;
	}
	public long getStockSize() {
		return stockSize;
	}
	public void setStockSize(long stockSize) {
		this.stockSize = stockSize;
	}
	public String getInventoryDescription() {
		return inventoryDescription;
	}
	public void setInventoryDescription(String inventoryDescription) {
		this.inventoryDescription = inventoryDescription;
	}
	public String getStoreLocation() {
		return storeLocation;
	}
	public void setStoreLocation(String storeLocation) {
		this.storeLocation = storeLocation;
	}
   

   
}
