package com.arpb.pickpaygo.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.arpb.pickpaygo.PickPayGoApplication;
import com.arpb.pickpaygo.exception.AppException;
import com.arpb.pickpaygo.model.CartProduct;
import com.arpb.pickpaygo.model.CustomerCart;
import com.arpb.pickpaygo.model.StoreInventory;
import com.arpb.pickpaygo.payload.PaymentRequest;
import com.arpb.pickpaygo.payload.PaymentResponse;
import com.arpb.pickpaygo.repository.CartProductRepository;
import com.arpb.pickpaygo.repository.CustomerCartRepository;
import com.arpb.pickpaygo.repository.StoreInventoryRepository;
import com.arpb.pickpaygo.util.ServiceUtil;
import com.braintreegateway.BraintreeGateway;
import com.braintreegateway.Customer;
import com.braintreegateway.CustomerRequest;
import com.braintreegateway.Result;
import com.braintreegateway.Transaction;
import com.braintreegateway.Transaction.Status;
import com.braintreegateway.TransactionRequest;

@Service
public class PaymentGatewayService {
	private Status[] TRANSACTION_SUCCESS_STATUSES = new Status[]{
			Transaction.Status.AUTHORIZED,
			Transaction.Status.AUTHORIZING,
			Transaction.Status.SETTLED,
			Transaction.Status.SETTLEMENT_CONFIRMED,
			Transaction.Status.SETTLEMENT_PENDING,
			Transaction.Status.SETTLING,
			Transaction.Status.SUBMITTED_FOR_SETTLEMENT
	};
	private BraintreeGateway gateway = PickPayGoApplication.gateway;

	@Autowired
	CustomerCartRepository customerCartRepository;
	@Autowired
	StoreInventoryRepository storeInventoryRepository;
	@Autowired
	ServiceUtil serviceUtil;
	@Autowired
	CartProductRepository cartProductRepository;

	public boolean checkoutCart(CustomerCart customerCart) throws MessagingException {
		List<CartProduct> cartProducts =customerCart.getCartProducts();
		try {
			for(CartProduct product: cartProducts)
			{
				StoreInventory inventory = product.getStoreInventory();
				inventory.setStockSize(inventory.getStockSize()-product.getQuantity());
				storeInventoryRepository.save(inventory);
			}
			customerCart.setCheckOutTime(serviceUtil.dateFormat());
			customerCart.setCheckedOut(true);
			customerCart = customerCartRepository.save(customerCart);
			//logoutUser(customerCartId);
			//	String userDetails = generateSoldProductResponse(productRequest);
			String userDetails = serviceUtil.generateCartResponse(customerCart.getUidpk(),cartProductRepository,customerCartRepository);
			serviceUtil.sendEmail(userDetails);
		}
		catch(Exception e)
		{
			System.out.println("Error in checkoutCart"+e);
			e.printStackTrace();
			return true;
		}
		return true;
	}
	public ResponseEntity processPayment(PaymentRequest paymentRequest)
	{
		Optional<CustomerCart> optional = customerCartRepository.findByUidpk(paymentRequest.getCustomerCartId());
		if(!optional.isPresent())
			throw new AppException("Customer information Could not be fetched.");
		CustomerCart customerCart = optional.get();
		BigDecimal decimalAmount = new BigDecimal(customerCart.getPrice());
		Transaction transactionDetails = null;
		Result<Customer> updateResult=null;
		try {

			CustomerRequest request = new CustomerRequest()
					.paymentMethodNonce(paymentRequest.getNonce());
			updateResult = gateway.customer().update(String.valueOf(customerCart.getUser().getUidpk()), request);
			TransactionRequest transactionRequest = new TransactionRequest()
					.amount(decimalAmount)
					.customerId(updateResult.getTarget().getId())
					.options()
					.submitForSettlement(true)
					.done();
			Result<Transaction> transactionResult = gateway.transaction().sale(transactionRequest);
			System.out.println("Transaction details" + transactionResult);
			if (transactionResult.isSuccess()) {
				transactionDetails = transactionResult.getTarget();
				checkoutCart(customerCart);
				System.out.println("Transaction Id " + transactionDetails.getId());
				System.out.println("CUstomer " + updateResult);
			}
		} catch (Exception e) {
			return ResponseEntity.ok(new PaymentResponse("Error in your transaction"));
		}
		return ResponseEntity.ok(new PaymentResponse(transactionDetails.getId(), updateResult.getTarget().getEmail(), "Successfull"));
	}
}
